//---------------------------------------------------------
// Assignment : Lab-04_a IPC_Pipes
// Date : 9/25/25
//
// Author : Lab-04_a-Pipes_Team02
//
// File Name : user.h
//---------------------------------------------------------
#ifndef USER_H
#define USER_H
#endif